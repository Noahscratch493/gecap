// Settings script for Gecap extension

document.addEventListener('DOMContentLoaded', async () => {
  const saveBtn = document.getElementById('saveBtn');
  const revokeConsentBtn = document.getElementById('revokeConsentBtn');
  const saveStatus = document.getElementById('saveStatus');
  const notificationTimeInput = document.getElementById('notificationTime');
  const frequencyRadios = document.querySelectorAll('input[name="frequency"]');
  
  // Load current settings
  const result = await chrome.storage.local.get(['settings']);
  
  if (result.settings) {
    const { frequency, notificationTime } = result.settings;
    
    // Set frequency radio
    frequencyRadios.forEach(radio => {
      if (radio.value === frequency) {
        radio.checked = true;
      }
    });
    
    // Set notification time
    notificationTimeInput.value = notificationTime;
  }
  
  // Save settings
  saveBtn.addEventListener('click', async () => {
    const frequency = document.querySelector('input[name="frequency"]:checked').value;
    const notificationTime = notificationTimeInput.value;
    
    // Save to storage
    await chrome.storage.local.set({
      settings: {
        frequency,
        notificationTime
      }
    });
    
    // Update alarm in background script
    await chrome.runtime.sendMessage({
      action: 'updateAlarm',
      frequency,
      time: notificationTime
    });
    
    // Show success message
    saveStatus.classList.remove('hidden');
    setTimeout(() => {
      saveStatus.classList.add('hidden');
    }, 3000);
  });
  
  // Revoke consent
  revokeConsentBtn.addEventListener('click', async () => {
    const confirmed = confirm(
      'Are you sure you want to revoke consent and clear all data?\n\n' +
      'This will:\n' +
      '• Delete all your search history\n' +
      '• Reset all settings\n' +
      '• Require you to accept consent again\n\n' +
      'This action cannot be undone.'
    );
    
    if (confirmed) {
      // Clear all data
      await chrome.storage.local.clear();
      
      // Show confirmation and close
      alert('All data has been cleared. The extension will now reset.');
      window.close();
    }
  });
});
