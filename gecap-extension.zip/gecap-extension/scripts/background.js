// Background service worker for Gecap extension

// Initialize extension on install
chrome.runtime.onInstalled.addListener(() => {
  console.log('Gecap extension installed');
  
  // Initialize default settings
  chrome.storage.local.get(['consentGiven', 'settings'], (result) => {
    if (!result.settings) {
      chrome.storage.local.set({
        settings: {
          frequency: 'weekly',
          notificationTime: '09:00'
        }
      });
    }
  });
});

// Listen for alarm to generate recap
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'generateRecap') {
    generateRecap();
  }
});

// Function to generate recap
async function generateRecap() {
  const result = await chrome.storage.local.get(['searchHistory', 'recapReady']);
  
  if (result.searchHistory && result.searchHistory.length > 0) {
    // Mark recap as ready
    await chrome.storage.local.set({ recapReady: true });
    
    // Send notification
    chrome.notifications.create({
      type: 'basic',
      iconUrl: '../icons/icon128.png',
      title: 'Gecap is Ready!',
      message: 'Your search history recap is ready to view.',
      priority: 2
    });
  }
}

// Update alarm based on settings
async function updateAlarm(frequency, time) {
  // Clear existing alarm
  chrome.alarms.clear('generateRecap');
  
  // Parse time (format: "HH:MM")
  const [hours, minutes] = time.split(':').map(Number);
  
  // Calculate delay in minutes
  const now = new Date();
  const scheduledTime = new Date();
  scheduledTime.setHours(hours, minutes, 0, 0);
  
  if (scheduledTime <= now) {
    scheduledTime.setDate(scheduledTime.getDate() + 1);
  }
  
  const delayInMinutes = Math.floor((scheduledTime - now) / 60000);
  
  // Calculate period in minutes based on frequency
  let periodInMinutes;
  switch (frequency) {
    case 'daily':
      periodInMinutes = 24 * 60; // 1 day
      break;
    case 'weekly':
      periodInMinutes = 7 * 24 * 60; // 7 days
      break;
    case 'monthly':
      periodInMinutes = 30 * 24 * 60; // 30 days
      break;
    case 'yearly':
      periodInMinutes = 365 * 24 * 60; // 365 days
      break;
    default:
      periodInMinutes = 7 * 24 * 60;
  }
  
  // Create new alarm
  chrome.alarms.create('generateRecap', {
    delayInMinutes: delayInMinutes,
    periodInMinutes: periodInMinutes
  });
}

// Listen for messages from other parts of the extension
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'updateAlarm') {
    updateAlarm(request.frequency, request.time);
    sendResponse({ success: true });
  } else if (request.action === 'manualGenerate') {
    generateRecap().then(() => {
      sendResponse({ success: true });
    });
    return true; // Keep channel open for async response
  } else if (request.action === 'saveSearchData') {
    saveSearchData(request.data).then(() => {
      sendResponse({ success: true });
    });
    return true;
  }
});

// Save search data to storage
async function saveSearchData(data) {
  const result = await chrome.storage.local.get(['searchHistory']);
  const searchHistory = result.searchHistory || [];
  
  // Add new search data
  searchHistory.push({
    query: data.query,
    url: data.url,
    timestamp: Date.now(),
    clickedLinks: data.clickedLinks || []
  });
  
  // Keep only last 10000 searches to prevent storage overflow
  if (searchHistory.length > 10000) {
    searchHistory.shift();
  }
  
  await chrome.storage.local.set({ searchHistory });
}

// Initialize alarm on startup
chrome.storage.local.get(['settings'], (result) => {
  if (result.settings) {
    updateAlarm(result.settings.frequency, result.settings.notificationTime);
  }
});
