// Content script for capturing Google search data

(async function() {
  // Check if consent is given
  const result = await chrome.storage.local.get(['consentGiven']);
  
  if (!result.consentGiven) {
    return; // Don't track if consent not given
  }
  
  // Extract search query from URL
  const urlParams = new URLSearchParams(window.location.search);
  const query = urlParams.get('q');
  
  if (!query) {
    return; // No search query found
  }
  
  // Track clicked links
  const clickedLinks = [];
  
  // Add click listeners to search result links
  const searchResults = document.querySelectorAll('a[href]');
  searchResults.forEach((link) => {
    link.addEventListener('click', () => {
      const href = link.href;
      const title = link.textContent.trim();
      
      // Only track external links (not Google's own links)
      if (href && !href.includes('google.com') && title) {
        clickedLinks.push({
          url: href,
          title: title,
          timestamp: Date.now()
        });
        
        // Save immediately when clicked
        chrome.runtime.sendMessage({
          action: 'saveSearchData',
          data: {
            query: query,
            url: window.location.href,
            clickedLinks: clickedLinks
          }
        });
      }
    });
  });
  
  // Save search data after a delay (in case user doesn't click anything)
  setTimeout(() => {
    chrome.runtime.sendMessage({
      action: 'saveSearchData',
      data: {
        query: query,
        url: window.location.href,
        clickedLinks: clickedLinks
      }
    });
  }, 3000);
})();
