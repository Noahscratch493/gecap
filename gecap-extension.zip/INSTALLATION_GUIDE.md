# Gecap Chrome Extension - Installation Guide

This guide will walk you through installing the Gecap Chrome Extension on your browser.

## What is Gecap?

Gecap is a Chrome Extension that tracks your Google Search history and generates beautiful analytics recaps. It shows you insights like your top search topics, most clicked websites, activity patterns, and more. All data stays on your device and is never sent to external servers.

## Installation Steps

### Step 1: Download the Extension

You should have received a file named `gecap-extension.zip`. Save it to a location on your computer where you can easily find it.

### Step 2: Extract the ZIP File

Extract the contents of `gecap-extension.zip` to a permanent location on your computer. This is important because Chrome will load the extension from this location, so don't delete the folder after installation.

**Windows**: Right-click the ZIP file and select "Extract All..."

**Mac**: Double-click the ZIP file to extract it automatically

**Linux**: Right-click and select "Extract Here" or use the command line

### Step 3: Open Chrome Extensions Page

Open Google Chrome and navigate to the extensions page using one of these methods:

- Type `chrome://extensions/` in the address bar and press Enter
- Click the three dots menu (⋮) → More Tools → Extensions
- Click the puzzle piece icon in the toolbar → Manage Extensions

### Step 4: Enable Developer Mode

In the top-right corner of the Extensions page, you'll see a toggle switch labeled "Developer mode". Click it to turn it ON. This allows you to load extensions that aren't from the Chrome Web Store.

### Step 5: Load the Extension

Once Developer Mode is enabled, you'll see new buttons appear at the top of the page. Click the "Load unpacked" button.

A file browser window will open. Navigate to the folder where you extracted the extension (the folder should be named `gecap-extension` and contain files like `manifest.json`). Select this folder and click "Select Folder" or "Open".

### Step 6: Verify Installation

The Gecap extension should now appear in your list of installed extensions. You should see:

- The Gecap icon (a purple circle with the letter "G")
- The name "Gecap"
- A description: "Recap your Google Search History with beautiful analytics and insights"
- The version number: 1.0.0

### Step 7: Pin the Extension (Optional but Recommended)

To make Gecap easily accessible:

1. Click the puzzle piece icon in your Chrome toolbar
2. Find "Gecap" in the list
3. Click the pin icon next to it

The Gecap icon will now appear in your Chrome toolbar for easy access.

## First-Time Setup

### Step 1: Accept Privacy Consent

When you first click the Gecap icon, you'll see a privacy notice explaining what data the extension collects and how it's used. Read through the notice carefully.

The extension needs your consent to:
- Track your Google search queries
- Record websites you click from search results
- Store this data locally on your device

**Important**: All data stays on your device. Nothing is sent to external servers.

Click "Accept & Continue" if you agree, or "No Thanks" to close the extension without enabling tracking.

### Step 2: Configure Settings

After accepting consent, click the settings icon (⚙️) in the extension popup to configure your preferences:

**Recap Frequency**: Choose how often you want automatic recaps generated
- Daily: Generate a recap every day
- Weekly: Generate a recap every week (default)
- Monthly: Generate a recap every month
- Yearly: Generate a recap every year

**Notification Time**: Set what time you want to be notified when your recap is ready (default is 9:00 AM)

Click "Save Settings" to apply your preferences.

## Using Gecap

### Automatic Recaps

Based on your configured frequency, Gecap will automatically generate a recap of your search history. When it's ready, you'll receive a browser notification. Click the Gecap icon and then click "Let's Gecap!" to view your analytics.

### Manual Recaps

You can generate a recap anytime by:
1. Clicking the Gecap icon in your toolbar
2. Clicking the "Generate a Gecap" button
3. Waiting a moment for it to process
4. Clicking "Let's Gecap!" to view your analytics

### Viewing Analytics

The recap page shows you:

- **Total Statistics**: Total searches, links clicked, unique websites visited, and average clicks per search
- **Top Search Topics**: Your most frequently searched queries
- **Search Categories**: Breakdown of your searches by category (Technology, Entertainment, Shopping, etc.)
- **Activity Over Time**: Graph showing your search activity over the past 30 days
- **Activity by Day of Week**: Which days you search the most
- **Activity by Hour**: What times of day you search the most
- **Most Clicked Websites**: The websites you visit most from search results

### Exporting Data

On the recap page, click the "Export Data" button to download all your search history and analytics as a JSON file. This can be useful for backup or further analysis.

## Managing Your Data

### Viewing Current Data

Click the Gecap icon to see a summary of your current statistics (total searches and links clicked).

### Clearing All Data

To delete all your search history:

1. Click the Gecap icon
2. Click "Clear All Data" at the bottom
3. Confirm the action

**Warning**: This action cannot be undone.

### Revoking Consent

To revoke consent and reset the extension:

1. Click the Gecap icon
2. Click the settings icon (⚙️)
3. Scroll down to the "Danger Zone" section
4. Click "Revoke Consent & Clear Data"
5. Confirm the action

This will delete all your data and require you to accept consent again if you want to use the extension.

## Troubleshooting

### Extension Not Tracking Searches

If Gecap isn't tracking your searches:

- Make sure you accepted the privacy consent when first opening the extension
- Verify that the extension is enabled on the Extensions page
- Check that you're searching on google.com (not other search engines)
- Try disabling and re-enabling the extension

### Recap Not Generating

If recaps aren't being generated:

- Make sure you have some search history (perform a few searches on Google first)
- Check your settings to ensure automatic recaps are configured correctly
- Try manually generating a recap using the "Generate a Gecap" button
- Check that Chrome notifications are enabled for the extension

### No Data Showing in Recap

If your recap shows no data:

- Ensure you're using Google.com for searches (not Bing, DuckDuckGo, etc.)
- Make sure you're clicking on search results (this is tracked separately)
- Wait a few seconds after searching for data to be saved
- Check that the extension has permission to access google.com

### Extension Icon Not Showing

If you can't see the Gecap icon:

- Click the puzzle piece icon in your Chrome toolbar
- Find "Gecap" in the list and click the pin icon
- The icon should now appear in your toolbar

## Uninstalling Gecap

If you want to remove Gecap:

1. Go to `chrome://extensions/`
2. Find "Gecap" in the list
3. Click the "Remove" button
4. Confirm the removal

All stored data will be automatically deleted when you remove the extension.

## Privacy & Security

Gecap is designed with privacy as a top priority:

- **Local Storage Only**: All your search history and analytics are stored locally in your browser using Chrome's storage API
- **No External Servers**: The extension does not communicate with any external servers or third parties
- **No Tracking**: Gecap doesn't track you or send any telemetry data
- **Full Control**: You can view, export, or delete all your data at any time
- **Open Source**: The extension code is available for review

## Technical Requirements

- **Browser**: Google Chrome (version 88 or later recommended)
- **Permissions**: The extension requires permissions to access Google.com URLs, local storage, alarms, notifications, and tabs
- **Storage**: Minimal storage space (typically less than 10 MB for extensive search history)

## Support

If you encounter any issues not covered in this guide:

1. Review the troubleshooting section above
2. Check the README.md file included with the extension
3. Verify you're using the latest version of Chrome
4. Try removing and reinstalling the extension

---

**Thank you for using Gecap! Happy searching! 🔍**
