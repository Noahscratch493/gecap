# 🔍 Gecap - Google Search History Recap Extension

Gecap is a Chrome Extension that helps you recap your Google Search history with beautiful analytics and insights.

## ✨ Features

- **Privacy-First**: All data stays on your device, nothing is sent to external servers
- **Automatic Recaps**: Schedule automatic recap generation (Daily, Weekly, Monthly, or Yearly)
- **Beautiful Analytics**: 
  - Top Search Topics
  - Most Clicked Websites
  - Activity Graphs (over time, by day, by hour)
  - Search Categories
  - Detailed Statistics
- **Data Export**: Export your search history and analytics as JSON
- **Customizable Notifications**: Choose when to be notified about ready recaps

## 📦 Installation Instructions

### Method 1: Load Unpacked Extension (Developer Mode)

1. **Open Chrome Extensions Page**
   - Open Google Chrome
   - Navigate to `chrome://extensions/`
   - Or click the three dots menu → More Tools → Extensions

2. **Enable Developer Mode**
   - Toggle the "Developer mode" switch in the top-right corner

3. **Load the Extension**
   - Click "Load unpacked" button
   - Navigate to and select the `gecap-extension` folder
   - The extension should now appear in your extensions list

4. **Pin the Extension** (Optional)
   - Click the puzzle piece icon in the Chrome toolbar
   - Find "Gecap" and click the pin icon to keep it visible

### Method 2: Install from ZIP

1. **Extract the ZIP file** to a permanent location on your computer
2. Follow the steps from Method 1 above

## 🚀 Getting Started

1. **First Launch**
   - Click the Gecap icon in your Chrome toolbar
   - Read and accept the privacy notice
   - The extension will start tracking your Google searches

2. **Configure Settings**
   - Click the settings icon (⚙️) in the popup
   - Choose your recap frequency (Daily, Weekly, Monthly, or Yearly)
   - Set your preferred notification time
   - Click "Save Settings"

3. **Generate a Recap**
   - Wait for the automatic recap notification, or
   - Click "Generate a Gecap" in the popup anytime
   - Click "Let's Gecap!" to view your analytics

## 📊 What Data is Collected?

Gecap tracks:
- Your Google search queries
- Websites you click from search results
- Timestamps of your searches

**Important**: All data is stored locally in your browser using Chrome's storage API. No data is sent to any external servers.

## 🔒 Privacy & Security

- ✅ All data stays on your device
- ✅ No external servers or third parties
- ✅ No tracking or analytics
- ✅ You can delete all data anytime
- ✅ You can revoke consent anytime

## 🛠️ Troubleshooting

### Extension not tracking searches
- Make sure you accepted the consent when first opening the extension
- Check that the extension has permission to access Google.com
- Try disabling and re-enabling the extension

### Recap not generating
- Make sure you have some search history (search on Google first)
- Check your settings to ensure automatic recaps are configured
- Try manually generating a recap using the "Generate a Gecap" button

### Data not showing
- Ensure you're searching on Google.com (not other search engines)
- Click on search results to track clicked websites
- Wait a few seconds after searching for data to be saved

## 🗑️ Uninstalling

To completely remove Gecap and all its data:

1. Go to `chrome://extensions/`
2. Find "Gecap" in the list
3. Click "Remove"
4. Confirm the removal

All stored data will be automatically deleted when you remove the extension.

## 📝 Technical Details

- **Manifest Version**: 3
- **Permissions**: storage, alarms, notifications, tabs, webNavigation
- **Host Permissions**: *.google.com/*
- **Storage**: Chrome Local Storage API
- **Charts**: Chart.js v4.4.0

## 🤝 Support

If you encounter any issues or have questions:
- Check the troubleshooting section above
- Review the privacy notice in the extension
- Make sure you're using the latest version of Chrome

## 📄 License

This extension is provided as-is for personal use.

---

**Enjoy your search history recaps with Gecap! 🎉**
