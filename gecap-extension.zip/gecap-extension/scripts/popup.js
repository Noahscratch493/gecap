// Popup script for Gecap extension

document.addEventListener('DOMContentLoaded', async () => {
  const consentScreen = document.getElementById('consentScreen');
  const mainScreen = document.getElementById('mainScreen');
  const acceptBtn = document.getElementById('acceptBtn');
  const declineBtn = document.getElementById('declineBtn');
  const settingsBtn = document.getElementById('settingsBtn');
  const generateBtn = document.getElementById('generateBtn');
  const viewRecapBtn = document.getElementById('viewRecapBtn');
  const clearDataBtn = document.getElementById('clearDataBtn');
  
  // Check consent status
  const result = await chrome.storage.local.get(['consentGiven', 'searchHistory', 'recapReady']);
  
  if (result.consentGiven) {
    showMainScreen();
    updateStats();
    checkRecapStatus();
  } else {
    consentScreen.classList.remove('hidden');
    mainScreen.classList.add('hidden');
  }
  
  // Accept consent
  acceptBtn.addEventListener('click', async () => {
    await chrome.storage.local.set({ consentGiven: true });
    consentScreen.classList.add('hidden');
    showMainScreen();
  });
  
  // Decline consent
  declineBtn.addEventListener('click', () => {
    window.close();
  });
  
  // Open settings
  settingsBtn.addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
  });
  
  // Generate recap manually
  generateBtn.addEventListener('click', async () => {
    generateBtn.disabled = true;
    generateBtn.textContent = 'Generating...';
    
    await chrome.runtime.sendMessage({ action: 'manualGenerate' });
    
    setTimeout(() => {
      generateBtn.disabled = false;
      generateBtn.textContent = 'Generate a Gecap';
      checkRecapStatus();
    }, 1000);
  });
  
  // View recap
  viewRecapBtn.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('pages/recap.html') });
  });
  
  // Clear all data
  clearDataBtn.addEventListener('click', async () => {
    if (confirm('Are you sure you want to clear all your search history data? This cannot be undone.')) {
      await chrome.storage.local.set({ 
        searchHistory: [],
        recapReady: false
      });
      updateStats();
      checkRecapStatus();
    }
  });
  
  // Show main screen
  function showMainScreen() {
    consentScreen.classList.add('hidden');
    mainScreen.classList.remove('hidden');
  }
  
  // Update statistics
  async function updateStats() {
    const result = await chrome.storage.local.get(['searchHistory']);
    const searchHistory = result.searchHistory || [];
    
    const totalSearches = searchHistory.length;
    let totalClicks = 0;
    
    searchHistory.forEach(search => {
      if (search.clickedLinks) {
        totalClicks += search.clickedLinks.length;
      }
    });
    
    document.getElementById('totalSearches').textContent = totalSearches;
    document.getElementById('totalClicks').textContent = totalClicks;
  }
  
  // Check recap status
  async function checkRecapStatus() {
    const result = await chrome.storage.local.get(['recapReady', 'settings']);
    
    const recapReadySection = document.getElementById('recapReadySection');
    const generateSection = document.getElementById('generateSection');
    
    if (result.recapReady) {
      recapReadySection.classList.remove('hidden');
      generateSection.classList.add('hidden');
    } else {
      recapReadySection.classList.add('hidden');
      generateSection.classList.remove('hidden');
    }
    
    // Update next recap time
    if (result.settings) {
      const { frequency, notificationTime } = result.settings;
      const nextRecap = calculateNextRecap(frequency, notificationTime);
      document.getElementById('nextRecapTime').textContent = nextRecap;
    }
  }
  
  // Calculate next recap time
  function calculateNextRecap(frequency, time) {
    const [hours, minutes] = time.split(':').map(Number);
    const now = new Date();
    const next = new Date();
    next.setHours(hours, minutes, 0, 0);
    
    if (next <= now) {
      switch (frequency) {
        case 'daily':
          next.setDate(next.getDate() + 1);
          break;
        case 'weekly':
          next.setDate(next.getDate() + 7);
          break;
        case 'monthly':
          next.setMonth(next.getMonth() + 1);
          break;
        case 'yearly':
          next.setFullYear(next.getFullYear() + 1);
          break;
      }
    }
    
    return next.toLocaleString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      hour: 'numeric', 
      minute: '2-digit' 
    });
  }
});
