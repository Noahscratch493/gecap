// Analytics utility for processing search history data

class GecapAnalytics {
  constructor(searchHistory) {
    this.searchHistory = searchHistory || [];
  }
  
  // Get top search topics
  getTopSearchTopics(limit = 10) {
    const queryCount = {};
    
    this.searchHistory.forEach(search => {
      const query = search.query.toLowerCase();
      queryCount[query] = (queryCount[query] || 0) + 1;
    });
    
    return Object.entries(queryCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, limit)
      .map(([query, count]) => ({ query, count }));
  }
  
  // Get most clicked websites
  getMostClickedWebsites(limit = 10) {
    const domainCount = {};
    
    this.searchHistory.forEach(search => {
      if (search.clickedLinks) {
        search.clickedLinks.forEach(link => {
          try {
            const url = new URL(link.url);
            const domain = url.hostname.replace('www.', '');
            domainCount[domain] = (domainCount[domain] || 0) + 1;
          } catch (e) {
            // Invalid URL, skip
          }
        });
      }
    });
    
    return Object.entries(domainCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, limit)
      .map(([domain, count]) => ({ domain, count }));
  }
  
  // Get activity by day of week
  getActivityByDayOfWeek() {
    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const dayCounts = new Array(7).fill(0);
    
    this.searchHistory.forEach(search => {
      const date = new Date(search.timestamp);
      const dayOfWeek = date.getDay();
      dayCounts[dayOfWeek]++;
    });
    
    return dayNames.map((day, index) => ({
      day,
      count: dayCounts[index]
    }));
  }
  
  // Get activity by hour of day
  getActivityByHour() {
    const hourCounts = new Array(24).fill(0);
    
    this.searchHistory.forEach(search => {
      const date = new Date(search.timestamp);
      const hour = date.getHours();
      hourCounts[hour]++;
    });
    
    return hourCounts.map((count, hour) => ({
      hour: `${hour}:00`,
      count
    }));
  }
  
  // Get activity over time (daily)
  getActivityOverTime(days = 30) {
    const now = Date.now();
    const oneDayMs = 24 * 60 * 60 * 1000;
    const activityMap = {};
    
    // Initialize all days with 0
    for (let i = days - 1; i >= 0; i--) {
      const date = new Date(now - i * oneDayMs);
      const dateKey = date.toISOString().split('T')[0];
      activityMap[dateKey] = 0;
    }
    
    // Count searches per day
    this.searchHistory.forEach(search => {
      const date = new Date(search.timestamp);
      const dateKey = date.toISOString().split('T')[0];
      
      if (activityMap.hasOwnProperty(dateKey)) {
        activityMap[dateKey]++;
      }
    });
    
    return Object.entries(activityMap).map(([date, count]) => ({
      date,
      count
    }));
  }
  
  // Get search categories (basic keyword analysis)
  getSearchCategories() {
    const categories = {
      'Technology': ['tech', 'software', 'code', 'programming', 'computer', 'app', 'website', 'ai', 'machine learning', 'data'],
      'Entertainment': ['movie', 'music', 'game', 'video', 'song', 'film', 'tv', 'show', 'netflix', 'youtube'],
      'Shopping': ['buy', 'shop', 'price', 'store', 'amazon', 'product', 'deal', 'sale'],
      'News': ['news', 'breaking', 'latest', 'update', 'today', 'current'],
      'Education': ['learn', 'tutorial', 'how to', 'course', 'study', 'education', 'university', 'school'],
      'Health': ['health', 'medical', 'doctor', 'symptom', 'fitness', 'diet', 'exercise'],
      'Travel': ['travel', 'flight', 'hotel', 'vacation', 'trip', 'destination'],
      'Food': ['recipe', 'food', 'restaurant', 'cooking', 'meal', 'dinner', 'lunch']
    };
    
    const categoryCounts = {};
    Object.keys(categories).forEach(cat => categoryCounts[cat] = 0);
    categoryCounts['Other'] = 0;
    
    this.searchHistory.forEach(search => {
      const query = search.query.toLowerCase();
      let matched = false;
      
      for (const [category, keywords] of Object.entries(categories)) {
        if (keywords.some(keyword => query.includes(keyword))) {
          categoryCounts[category]++;
          matched = true;
          break;
        }
      }
      
      if (!matched) {
        categoryCounts['Other']++;
      }
    });
    
    return Object.entries(categoryCounts)
      .filter(([_, count]) => count > 0)
      .sort((a, b) => b[1] - a[1])
      .map(([category, count]) => ({ category, count }));
  }
  
  // Get total statistics
  getTotalStats() {
    let totalClicks = 0;
    const uniqueDomains = new Set();
    
    this.searchHistory.forEach(search => {
      if (search.clickedLinks) {
        totalClicks += search.clickedLinks.length;
        
        search.clickedLinks.forEach(link => {
          try {
            const url = new URL(link.url);
            uniqueDomains.add(url.hostname.replace('www.', ''));
          } catch (e) {
            // Invalid URL, skip
          }
        });
      }
    });
    
    return {
      totalSearches: this.searchHistory.length,
      totalClicks,
      uniqueWebsites: uniqueDomains.size,
      averageClicksPerSearch: this.searchHistory.length > 0 
        ? (totalClicks / this.searchHistory.length).toFixed(2) 
        : 0
    };
  }
}

// Make available globally
if (typeof window !== 'undefined') {
  window.GecapAnalytics = GecapAnalytics;
}
