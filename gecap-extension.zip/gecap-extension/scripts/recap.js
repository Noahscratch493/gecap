// Recap script for Gecap extension

document.addEventListener('DOMContentLoaded', async () => {
  const closeBtn = document.getElementById('closeBtn');
  const exportBtn = document.getElementById('exportBtn');
  
  // Load search history
  const result = await chrome.storage.local.get(['searchHistory']);
  const searchHistory = result.searchHistory || [];
  
  if (searchHistory.length === 0) {
    document.querySelector('main').innerHTML = `
      <div class="loading">
        <h2>No search history yet!</h2>
        <p>Start searching on Google to see your recap.</p>
      </div>
    `;
    return;
  }
  
  // Initialize analytics
  const analytics = new GecapAnalytics(searchHistory);
  
  // Display date range
  displayDateRange(searchHistory);
  
  // Display total stats
  displayTotalStats(analytics);
  
  // Display top topics
  displayTopTopics(analytics);
  
  // Display most clicked websites
  displayMostClickedWebsites(analytics);
  
  // Create charts
  createCategoriesChart(analytics);
  createActivityChart(analytics);
  createDayOfWeekChart(analytics);
  createHourChart(analytics);
  
  // Mark recap as viewed
  await chrome.storage.local.set({ recapReady: false });
  
  // Close button
  closeBtn.addEventListener('click', () => {
    window.close();
  });
  
  // Export button
  exportBtn.addEventListener('click', () => {
    exportData(searchHistory, analytics);
  });
});

// Display date range
function displayDateRange(searchHistory) {
  if (searchHistory.length === 0) return;
  
  const timestamps = searchHistory.map(s => s.timestamp);
  const earliest = new Date(Math.min(...timestamps));
  const latest = new Date(Math.max(...timestamps));
  
  const dateRange = document.getElementById('dateRange');
  dateRange.textContent = `${earliest.toLocaleDateString()} - ${latest.toLocaleDateString()}`;
}

// Display total stats
function displayTotalStats(analytics) {
  const stats = analytics.getTotalStats();
  
  document.getElementById('totalSearches').textContent = stats.totalSearches;
  document.getElementById('totalClicks').textContent = stats.totalClicks;
  document.getElementById('uniqueWebsites').textContent = stats.uniqueWebsites;
  document.getElementById('avgClicks').textContent = stats.averageClicksPerSearch;
}

// Display top topics
function displayTopTopics(analytics) {
  const topics = analytics.getTopSearchTopics(10);
  const topicsList = document.getElementById('topicsList');
  
  if (topics.length === 0) {
    topicsList.innerHTML = '<div class="loading">No topics found</div>';
    return;
  }
  
  topicsList.innerHTML = topics.map(topic => `
    <div class="topic-item">
      <div class="topic-query">${escapeHtml(topic.query)}</div>
      <div class="topic-count">${topic.count}</div>
    </div>
  `).join('');
}

// Display most clicked websites
function displayMostClickedWebsites(analytics) {
  const websites = analytics.getMostClickedWebsites(10);
  const websitesList = document.getElementById('websitesList');
  
  if (websites.length === 0) {
    websitesList.innerHTML = '<div class="loading">No websites found</div>';
    return;
  }
  
  websitesList.innerHTML = websites.map(website => `
    <div class="website-item">
      <div class="website-domain">${escapeHtml(website.domain)}</div>
      <div class="website-count">${website.count}</div>
    </div>
  `).join('');
}

// Create categories chart
function createCategoriesChart(analytics) {
  const categories = analytics.getSearchCategories();
  
  if (categories.length === 0) return;
  
  const ctx = document.getElementById('categoriesChart').getContext('2d');
  
  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: categories.map(c => c.category),
      datasets: [{
        data: categories.map(c => c.count),
        backgroundColor: [
          '#667eea',
          '#764ba2',
          '#f093fb',
          '#4facfe',
          '#43e97b',
          '#fa709a',
          '#fee140',
          '#30cfd0',
          '#a8edea',
          '#fbc2eb'
        ],
        borderWidth: 0
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          position: 'right',
          labels: {
            padding: 15,
            font: {
              size: 14
            }
          }
        }
      }
    }
  });
}

// Create activity over time chart
function createActivityChart(analytics) {
  const activity = analytics.getActivityOverTime(30);
  
  const ctx = document.getElementById('activityChart').getContext('2d');
  
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: activity.map(a => {
        const date = new Date(a.date);
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
      }),
      datasets: [{
        label: 'Searches',
        data: activity.map(a => a.count),
        borderColor: '#667eea',
        backgroundColor: 'rgba(102, 126, 234, 0.1)',
        fill: true,
        tension: 0.4,
        borderWidth: 3,
        pointRadius: 4,
        pointHoverRadius: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          display: false
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            precision: 0
          }
        }
      }
    }
  });
}

// Create day of week chart
function createDayOfWeekChart(analytics) {
  const dayActivity = analytics.getActivityByDayOfWeek();
  
  const ctx = document.getElementById('dayOfWeekChart').getContext('2d');
  
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: dayActivity.map(d => d.day),
      datasets: [{
        label: 'Searches',
        data: dayActivity.map(d => d.count),
        backgroundColor: '#764ba2',
        borderRadius: 8,
        borderSkipped: false
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          display: false
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            precision: 0
          }
        }
      }
    }
  });
}

// Create hour of day chart
function createHourChart(analytics) {
  const hourActivity = analytics.getActivityByHour();
  
  const ctx = document.getElementById('hourChart').getContext('2d');
  
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: hourActivity.map(h => h.hour),
      datasets: [{
        label: 'Searches',
        data: hourActivity.map(h => h.count),
        backgroundColor: '#667eea',
        borderRadius: 8,
        borderSkipped: false
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: true,
      plugins: {
        legend: {
          display: false
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          ticks: {
            precision: 0
          }
        }
      }
    }
  });
}

// Export data as JSON
function exportData(searchHistory, analytics) {
  const exportData = {
    generatedAt: new Date().toISOString(),
    totalStats: analytics.getTotalStats(),
    topTopics: analytics.getTopSearchTopics(20),
    mostClickedWebsites: analytics.getMostClickedWebsites(20),
    searchCategories: analytics.getSearchCategories(),
    activityByDay: analytics.getActivityByDayOfWeek(),
    activityByHour: analytics.getActivityByHour(),
    activityOverTime: analytics.getActivityOverTime(30),
    rawSearchHistory: searchHistory
  };
  
  const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `gecap-export-${new Date().toISOString().split('T')[0]}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}
